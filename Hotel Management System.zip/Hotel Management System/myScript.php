<?php
    $con = mysqli_connect("localhost","root","","hoteldatabase");

        $scrName = mysqli_real_escape_string($con, $_POST['Name']);
        $scrSurname = mysqli_real_escape_string($con, $_POST['Surname']);
        $scrDate_of_Birth  = mysqli_real_escape_string($con, $_POST['Date_of_Birth']);
        $scrEmail = mysqli_real_escape_string($con, $_POST['Email']);
        $scrContact = mysqli_real_escape_string($con, $_POST['Contact']);
        $scrNationality = mysqli_real_escape_string($con, $_POST['Nationality']);
        $scrID_Number = mysqli_real_escape_string($con, $_POST['ID_Number']);
        $scrAddress = mysqli_real_escape_string($con, $_POST['Address']);
        $scrNext_of_Kin = mysqli_real_escape_string($con, $_POST['Next_of_Kin']);
        $scrNext_of_Kin_Contact = mysqli_real_escape_string($con, $_POST['Next_of_Kin_Contact']);
        $scrTime_of_Duration = mysqli_real_escape_string($con, $_POST['Time_of_Duration']);
        $scrNumber_of_Guests = mysqli_real_escape_string($con, $_POST['Number_of_Guests']);
        $scrNumber_of_Rooms = mysqli_real_escape_string($con, $_POST['Number_of_Rooms']);
        $scrCheck_In_Date = mysqli_real_escape_string($con, $_POST['Check_In_Date']);

    $ssql = "insert into hoteltable(Name, Surname, Date_of_Birth, Email, Contact, Nationality, ID_Number, Address, Next_of_Kin, Next_of_Kin_Contact, Time_of_Duration, Number_of_Guests, Number_of_Rooms, Check_In_Date) values ('$scrName', '$scrSurname', '$scrDate_of_Birth', '$scrEmail', '$scrContact', '$scrNationality', '$scrID_Number', '$scrAddress', '$scrNext_of_Kin', '$scrNext_of_Kin_Contact', '$scrTime_of_Duration', '$scrNumber_of_Guests', '$scrNumber_of_Rooms', '$scrCheck_In_Date')";

if(mysqli_query($con,$ssql))
{
	echo "Booking was successful, Please proceed to payments....";
}
else
{
	die('Cannot save to database');
}
mysqli_close($con);

?>
