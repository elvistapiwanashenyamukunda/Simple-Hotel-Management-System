<?php
    $con = mysqli_connect("localhost","root","","hotelpayments");

        $scrName = mysqli_real_escape_string($con, $_POST['Name']);
        $scrSurname = mysqli_real_escape_string($con, $_POST['Surname']);
        $scrContact  = mysqli_real_escape_string($con, $_POST['Contact']);
        $scrAmountUSD = mysqli_real_escape_string($con, $_POST['AmountUSD']);
$ssql = "insert into paymenttable(Name, Surname, Contact, AmountUSD) values ('$scrName', '$scrSurname', '$scrContact', '$scrAmountUSD')";
if(mysqli_query($con,$ssql))
{
	echo ("Succesfully paid!!!....");
}
else
{
	die('Payment Unsuccessful');
}
mysqli_close($con);
?>