<?php
    $con = mysqli_connect("localhost","root","","hotelreviews");

        $scrName = mysqli_real_escape_string($con, $_POST['Name']);
        $scrSurname = mysqli_real_escape_string($con, $_POST['Surname']);
        $scrComments = mysqli_real_escape_string($con, $_POST['Comments']);
$ssql = "insert into reviewstable(Name, Surname, Comments) values ('$scrName', '$scrSurname', '$scrComments')";
if(mysqli_query($con,$ssql))
{
	echo ("Comment Successfully Posted!!!....");
}
else
{
	die('Unable to Post Comment');
}
mysqli_close($con);
?>